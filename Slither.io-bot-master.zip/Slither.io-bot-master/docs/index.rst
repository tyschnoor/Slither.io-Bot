.. Slither.io-bot documentation master file, created by
   sphinx-quickstart on Fri May 13 18:29:29 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Slither.io-bot's documentation!
==========================================

Contents:

.. toctree::
   :maxdepth: 2

   game-variables
   conversion_algorithms


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
